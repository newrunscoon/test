// ============================================================
// 테트리스 핵심 데이터 및 그리기
// (자동 낙하 + 키보드 조작)
// ============================================================

// --- 캔버스 설정 ---
const canvas = document.getElementById('game-board');
const ctx = canvas.getContext('2d');
const nextCanvas = document.getElementById('next-preview');
const nextCtx = nextCanvas.getContext('2d');

// --- 보드 크기 (가로 10칸 × 세로 20칸) ---
const COLS = 10;
const ROWS = 20;

// 캔버스 크기(300×600)에 맞춘 한 칸의 픽셀 크기
const BLOCK_SIZE = canvas.width / COLS; // 30px

// --- 다음 블록 미리보기 (4×4 격자) ---
const NEXT_PREVIEW_COLS = 4;
const NEXT_BLOCK_SIZE = nextCanvas.width / NEXT_PREVIEW_COLS;

// --- 7가지 테트로미노: 모양(2D 배열) + 색상 ---
// shape에서 1은 블록이 있는 칸, 0은 빈 칸
const TETROMINOS = {
  I: {
    color: '#00f0f0', // 시안
    shape: [
      [0, 0, 0, 0],
      [1, 1, 1, 1],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ],
  },
  O: {
    color: '#f0f000', // 노랑
    shape: [
      [1, 1],
      [1, 1],
    ],
  },
  T: {
    color: '#a000f0', // 보라
    shape: [
      [0, 1, 0],
      [1, 1, 1],
      [0, 0, 0],
    ],
  },
  S: {
    color: '#00f000', // 초록
    shape: [
      [0, 1, 1],
      [1, 1, 0],
      [0, 0, 0],
    ],
  },
  Z: {
    color: '#f00000', // 빨강
    shape: [
      [1, 1, 0],
      [0, 1, 1],
      [0, 0, 0],
    ],
  },
  J: {
    color: '#0000f0', // 파랑
    shape: [
      [1, 0, 0],
      [1, 1, 1],
      [0, 0, 0],
    ],
  },
  L: {
    color: '#f0a000', // 주황
    shape: [
      [0, 0, 1],
      [1, 1, 1],
      [0, 0, 0],
    ],
  },
};

// --- 보드 그리드 ---
// 각 칸은 null(비어 있음) 또는 색상 문자열(고정된 블록)
// board[row][col] 형태 — row 0이 맨 위
const board = Array.from({ length: ROWS }, () =>
  Array(COLS).fill(null)
);

// --- 게임 설정 ---
const BASE_DROP_INTERVAL_MS = 500;
const MIN_DROP_INTERVAL_MS = 100;
const DROP_SPEED_DECREASE_MS = 35; // 레벨마다 낙하 간격 감소
const SCORE_PER_LEVEL = 500; // 점수 500마다 레벨 상승
const PIECE_TYPES = Object.keys(TETROMINOS);

// 줄 삭제 수에 따른 점수 (동시에 여러 줄 지울 때 한 번에 가산)
const LINE_SCORES = {
  1: 100,
  2: 300,
  3: 500,
  4: 800,
};

// --- UI ---
const scoreElement = document.getElementById('score');
const levelElement = document.getElementById('level');
const linesElement = document.getElementById('lines');
const gameOverOverlay = document.getElementById('game-over-overlay');
const restartBtn = document.getElementById('restart-btn');

// --- 현재·다음 블록 ---
let nextPieceType = randomPieceType();
let currentPiece = createPiece(randomPieceType());
let dropTimerId = null;
let isGameOver = false;
let score = 0;
let totalLines = 0;
let level = 1;

// ============================================================
// 충돌 판정 · 블록 생성 · 낙하
// ============================================================

/**
 * 보드 경계 및 고정 블록과의 충돌을 검사한다.
 * piece를 (x, y) 위치에 둘 수 있으면 true, 아니면 false.
 * @param {{ shape: number[][] }} piece
 * @param {(string|null)[][]} grid
 * @param {number} x - 보드 열 오프셋
 * @param {number} y - 보드 행 오프셋
 * @returns {boolean}
 */
function canPlacePiece(piece, grid, x, y) {
  const { shape } = piece;

  for (let row = 0; row < shape.length; row++) {
    for (let col = 0; col < shape[row].length; col++) {
      if (!shape[row][col]) continue;

      const boardCol = x + col;
      const boardRow = y + row;

      // 좌·우·아래 경계 밖이면 배치 불가
      if (boardCol < 0 || boardCol >= COLS || boardRow >= ROWS) {
        return false;
      }

      // 위쪽(row < 0)은 보드 밖 스폰 구간 — 고정 블록만 검사하지 않음
      if (boardRow < 0) continue;

      if (grid[boardRow][boardCol] !== null) {
        return false;
      }
    }
  }

  return true;
}

/** 랜덤 테트로미노 타입 반환 */
function randomPieceType() {
  return PIECE_TYPES[Math.floor(Math.random() * PIECE_TYPES.length)];
}

/**
 * 새 테트로미노 생성 (보드 맨 위 중앙 스폰)
 * @param {string} type - I, O, T, S, Z, J, L
 */
function createPiece(type) {
  const { shape, color } = TETROMINOS[type];
  return {
    type,
    shape: shape.map((row) => [...row]),
    color,
    x: Math.floor((COLS - shape[0].length) / 2),
    y: 0,
  };
}

function resetPieceQueue() {
  currentPiece = createPiece(randomPieceType());
  nextPieceType = randomPieceType();
}

/**
 * 가득 찬 줄을 삭제하고 위 블록을 한 칸씩 내린다.
 * 동시에 여러 줄이 차 있으면 모두 처리한다.
 * @returns {number} 삭제된 줄 수
 */
function clearFullLines() {
  let linesCleared = 0;

  for (let row = ROWS - 1; row >= 0; row--) {
    if (board[row].every((cell) => cell !== null)) {
      board.splice(row, 1);
      board.unshift(Array(COLS).fill(null));
      linesCleared++;
      row++; // 같은 인덱스를 다시 검사 (위에서 내려온 줄)
    }
  }

  return linesCleared;
}

/** 삭제된 줄 수에 따라 점수를 더하고 화면을 갱신한다 */
function addLineScore(linesCleared) {
  if (linesCleared === 0) return;

  score += LINE_SCORES[linesCleared] ?? 0;
  totalLines += linesCleared;
  updateScoreDisplay();
  updateLevel();
}

function getLevelFromScore(currentScore) {
  return Math.floor(currentScore / SCORE_PER_LEVEL) + 1;
}

function getDropIntervalMs(currentLevel) {
  return Math.max(
    MIN_DROP_INTERVAL_MS,
    BASE_DROP_INTERVAL_MS - (currentLevel - 1) * DROP_SPEED_DECREASE_MS
  );
}

function updateLevel() {
  const newLevel = getLevelFromScore(score);
  if (newLevel === level) {
    levelElement.textContent = String(level);
    return;
  }

  level = newLevel;
  levelElement.textContent = String(level);

  if (!isGameOver) {
    restartDropLoop();
  }
}

function updateScoreDisplay() {
  scoreElement.textContent = String(score);
  linesElement.textContent = String(totalLines);
  levelElement.textContent = String(level);
}

/** 현재 블록을 보드에 고정 */
function lockPiece(piece) {
  const { shape, color, x, y } = piece;

  for (let row = 0; row < shape.length; row++) {
    for (let col = 0; col < shape[row].length; col++) {
      if (!shape[row][col]) continue;

      const boardRow = y + row;
      const boardCol = x + col;

      if (boardRow >= 0 && boardRow < ROWS && boardCol >= 0 && boardCol < COLS) {
        board[boardRow][boardCol] = color;
      }
    }
  }
}

/** (dx, dy)만큼 이동 시도. 성공 시 true */
function tryMove(dx, dy) {
  const nextX = currentPiece.x + dx;
  const nextY = currentPiece.y + dy;

  if (!canPlacePiece(currentPiece, board, nextX, nextY)) {
    return false;
  }

  currentPiece.x = nextX;
  currentPiece.y = nextY;
  return true;
}

/** 현재 블록 고정 후 줄 삭제·점수 처리·다음 블록 스폰 */
function lockAndSpawnNext() {
  lockPiece(currentPiece);
  addLineScore(clearFullLines());
  currentPiece = createPiece(nextPieceType);
  nextPieceType = randomPieceType();

  if (!canPlacePiece(currentPiece, board, currentPiece.x, currentPiece.y)) {
    triggerGameOver();
  }
}

function triggerGameOver() {
  isGameOver = true;
  stopDropLoop();
  gameOverOverlay.classList.remove('hidden');
  gameOverOverlay.setAttribute('aria-hidden', 'false');
}

function hideGameOverOverlay() {
  gameOverOverlay.classList.add('hidden');
  gameOverOverlay.setAttribute('aria-hidden', 'true');
}

function resetBoard() {
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      board[row][col] = null;
    }
  }
}

function restartGame() {
  resetBoard();
  score = 0;
  totalLines = 0;
  level = 1;
  isGameOver = false;
  updateScoreDisplay();
  hideGameOverOverlay();
  resetPieceQueue();
  draw();
  restartDropLoop();
}

/** 한 칸 아래로 이동 시도. 막히면 고정 후 새 블록 스폰 */
function tryMoveDown() {
  if (!tryMove(0, 1)) {
    lockAndSpawnNext();
  }
}

/** shape를 시계방향 90° 회전한 새 2D 배열 반환 */
function rotateClockwise(shape) {
  const rows = shape.length;
  const cols = shape[0].length;
  const rotated = Array.from({ length: cols }, () => Array(rows).fill(0));

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      rotated[col][rows - 1 - row] = shape[row][col];
    }
  }

  return rotated;
}

/** 시계방향 회전. 충돌 시 원래 모양으로 되돌림 */
function tryRotateClockwise() {
  const originalShape = currentPiece.shape;
  currentPiece.shape = rotateClockwise(originalShape);

  if (!canPlacePiece(currentPiece, board, currentPiece.x, currentPiece.y)) {
    currentPiece.shape = originalShape;
  }
}

/** 바닥·블록에 닿을 때까지 연속 낙하 후 고정 */
function hardDrop() {
  while (tryMove(0, 1)) {}
  lockAndSpawnNext();
}

function tick() {
  if (isGameOver) return;
  tryMoveDown();
  draw();
}

function startDropLoop() {
  if (dropTimerId !== null) return;
  dropTimerId = setInterval(tick, getDropIntervalMs(level));
}

function restartDropLoop() {
  stopDropLoop();
  startDropLoop();
}

function stopDropLoop() {
  if (dropTimerId === null) return;
  clearInterval(dropTimerId);
  dropTimerId = null;
}

// ============================================================
// 그리기 헬퍼
// ============================================================

/** 캔버스 전체를 검은색으로 지움 */
function clearCanvas() {
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

/** 보드 격자선 그리기 (10×20 구분선) */
function drawGrid() {
  ctx.strokeStyle = '#222';
  ctx.lineWidth = 1;

  // 세로선
  for (let col = 0; col <= COLS; col++) {
    const x = col * BLOCK_SIZE;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }

  // 가로선
  for (let row = 0; row <= ROWS; row++) {
    const y = row * BLOCK_SIZE;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }
}

/**
 * 보드에 고정된 블록 한 칸 그리기
 * @param {number} col - 보드 열 (0~9)
 * @param {number} row - 보드 행 (0~19)
 * @param {string} color - 채울 색상
 */
function drawCell(col, row, color) {
  const x = col * BLOCK_SIZE;
  const y = row * BLOCK_SIZE;
  const padding = 1; // 칸 사이 얇은 간격

  ctx.fillStyle = color;
  ctx.fillRect(
    x + padding,
    y + padding,
    BLOCK_SIZE - padding * 2,
    BLOCK_SIZE - padding * 2
  );
}

/** 보드에 이미 쌓인 블록들 그리기 */
function drawBoard() {
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const cell = board[row][col];
      if (cell) {
        drawCell(col, row, cell);
      }
    }
  }
}

/**
 * 현재 떨어지는 테트로미노 그리기
 * piece.shape의 1인 위치에만 블록을 그림
 */
function drawPiece(piece) {
  const { shape, color, x: offsetX, y: offsetY } = piece;

  for (let row = 0; row < shape.length; row++) {
    for (let col = 0; col < shape[row].length; col++) {
      if (shape[row][col]) {
        drawCell(offsetX + col, offsetY + row, color);
      }
    }
  }
}

/** 다음 블록 미리보기 캔버스에 그리기 */
function drawNextPreview() {
  nextCtx.fillStyle = '#000';
  nextCtx.fillRect(0, 0, nextCanvas.width, nextCanvas.height);

  const { shape, color } = TETROMINOS[nextPieceType];
  const offsetX = Math.floor((NEXT_PREVIEW_COLS - shape[0].length) / 2);
  const offsetY = Math.floor((NEXT_PREVIEW_COLS - shape.length) / 2);
  const padding = 1;

  for (let row = 0; row < shape.length; row++) {
    for (let col = 0; col < shape[row].length; col++) {
      if (!shape[row][col]) continue;

      const x = (offsetX + col) * NEXT_BLOCK_SIZE;
      const y = (offsetY + row) * NEXT_BLOCK_SIZE;

      nextCtx.fillStyle = color;
      nextCtx.fillRect(
        x + padding,
        y + padding,
        NEXT_BLOCK_SIZE - padding * 2,
        NEXT_BLOCK_SIZE - padding * 2
      );
    }
  }
}

// ============================================================
// 메인 draw() — 보드 격자 + 고정 블록 + 현재 블록
// ============================================================
function draw() {
  clearCanvas();
  drawGrid();
  drawBoard();
  drawPiece(currentPiece);
  drawNextPreview();
}

// ============================================================
// 키보드 입력
// ============================================================
document.addEventListener('keydown', (e) => {
  if (isGameOver) return;

  let handled = false;

  switch (e.key) {
    case 'ArrowLeft':
      tryMove(-1, 0);
      handled = true;
      break;
    case 'ArrowRight':
      tryMove(1, 0);
      handled = true;
      break;
    case 'ArrowDown':
      tryMoveDown();
      handled = true;
      break;
    case 'ArrowUp':
      tryRotateClockwise();
      handled = true;
      break;
    case ' ':
      hardDrop();
      handled = true;
      break;
  }

  if (handled) {
    e.preventDefault();
    draw();
  }
});

restartBtn.addEventListener('click', restartGame);

// 최초 그리기 후 자동 낙하 시작
draw();
startDropLoop();
