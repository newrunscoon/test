import http from 'node:http';
import { login } from './auth.js';

const DEFAULT_PORT = 3000;

/**
 * JSON 응답을 전송한다.
 * @param {import('node:http').ServerResponse} res - HTTP 응답 객체
 * @param {number} statusCode - HTTP 상태 코드
 * @param {unknown} body - 응답 본문
 */
function sendJson(res, statusCode, body) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body));
}

/**
 * 요청 본문을 JSON으로 파싱한다.
 * @param {import('node:http').IncomingMessage} req - HTTP 요청 객체
 * @returns {Promise<unknown>} 파싱된 JSON 객체
 */
function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let totalLength = 0;

    req.on('data', (chunk) => {
      totalLength += chunk.length;
      if (totalLength > 10_240) {
        reject(new Error('요청 본문이 너무 큽니다.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => {
      if (chunks.length === 0) {
        resolve({});
        return;
      }

      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new Error('유효하지 않은 JSON입니다.'));
      }
    });

    req.on('error', reject);
  });
}

/**
 * 로그인 API 요청을 처리한다.
 * @param {import('node:http').IncomingMessage} req - HTTP 요청 객체
 * @param {import('node:http').ServerResponse} res - HTTP 응답 객체
 */
async function handleLogin(req, res) {
  try {
    const body = await readJsonBody(req);
    const email = body?.email;
    const password = body?.password;

    const result = login(email, password);
    if (!result) {
      sendJson(res, 401, { error: '이메일 또는 비밀번호가 올바르지 않습니다.' });
      return;
    }

    sendJson(res, 200, result);
  } catch {
    sendJson(res, 400, { error: '요청 형식이 올바르지 않습니다.' });
  }
}

/**
 * HTTP 요청 라우터.
 * @param {import('node:http').IncomingMessage} req - HTTP 요청 객체
 * @param {import('node:http').ServerResponse} res - HTTP 응답 객체
 */
async function handleRequest(req, res) {
  const { method, url } = req;

  if (method === 'POST' && url === '/api/login') {
    await handleLogin(req, res);
    return;
  }

  sendJson(res, 404, { error: '요청한 리소스를 찾을 수 없습니다.' });
}

/**
 * API 서버를 생성한다.
 * @param {number} [port=DEFAULT_PORT] - 수신 포트
 * @returns {import('node:http').Server} HTTP 서버 인스턴스
 */
export function createServer(port = DEFAULT_PORT) {
  const server = http.createServer((req, res) => {
    handleRequest(req, res).catch(() => {
      sendJson(res, 500, { error: '서버 내부 오류가 발생했습니다.' });
    });
  });

  server.listen(port);
  return server;
}
