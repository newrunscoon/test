import { createServer } from './server.js';

const port = Number(process.env.PORT) || 3000;
createServer(port);
