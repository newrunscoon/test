import { isValidEmail, normalizeEmail } from './validator.js';

/**
 * 사용자 목록에서 이메일만 추출한다.
 * @param {unknown} users - 사용자 배열
 * @returns {string[]} 이메일 목록
 */
export function extractEmails(users) {
  if (!Array.isArray(users)) {
    return [];
  }
  return users.map((user) => user.email);
}

/**
 * 유효한 이메일만 추출한다.
 * @param {unknown} users - 사용자 배열
 * @returns {string[]} 유효한 이메일 목록
 */
export function getValidEmails(users) {
  if (!Array.isArray(users)) {
    return [];
  }

  const validEmails = [];
  for (const user of users) {
    const email = user.email;
    if (isValidEmail(email)) {
      validEmails.push(email);
    }
  }
  return validEmails;
}

export { isValidEmail, normalizeEmail };
