// RFC 5322 전체 문법은 정규식으로 다루기 어렵다. 실용적 권장안:
// /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/
// + RFC 5322 로컬 파트 64자, RFC 5321 SMTP 전체 254자 제한
const EMAIL_REGEX = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
const MAX_LOCAL_PART_LENGTH = 64;
const MAX_EMAIL_LENGTH = 254;

/**
 * 이메일 형식이 유효한지 검사한다.
 * @param {unknown} email - 검사할 이메일
 * @returns {boolean} 유효 여부
 */
export function isValidEmail(email) {
  if (typeof email !== 'string') {
    return false;
  }
  const trimmed = email.trim();
  if (trimmed.length === 0 || trimmed.length > MAX_EMAIL_LENGTH) {
    return false;
  }
  const atIndex = trimmed.indexOf('@');
  if (atIndex <= 0 || atIndex > MAX_LOCAL_PART_LENGTH) {
    return false;
  }
  return EMAIL_REGEX.test(trimmed);
}

/**
 * 이메일 문자열을 비교·저장에 쓰기 좋게 정규화한다.
 * @param {unknown} email - 정규화할 이메일
 * @returns {string|null} 앞뒤 공백을 제거하고 소문자로 변환한 이메일. 문자열이 아니면 null
 */
export function normalizeEmail(email) {
  if (typeof email !== 'string') {
    return null;
  }
  const normalized = email.trim().toLowerCase();
  return normalized.length > 0 ? normalized : null;
}
