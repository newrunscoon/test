import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { login } from './auth.js';
import { createServer } from './server.js';

describe('login', () => {
  before(() => {
    process.env.AUTH_SECRET = 'test-secret-key';
  });

  it('올바른 자격 증명으로 토큰을 발급한다', () => {
    const result = login('admin@example.com', 'admin123');
    assert.ok(result);
    assert.equal(typeof result.token, 'string');
    assert.equal(result.expiresIn, 3600);
  });

  it('잘못된 비밀번호를 거부한다', () => {
    assert.equal(login('admin@example.com', 'wrong'), null);
  });

  it('존재하지 않는 이메일을 거부한다', () => {
    assert.equal(login('unknown@example.com', 'admin123'), null);
  });

  it('유효하지 않은 이메일 형식을 거부한다', () => {
    assert.equal(login('not-an-email', 'admin123'), null);
  });
});

describe('POST /api/login', () => {
  /** @type {import('node:http').Server} */
  let server;
  const port = 3456;

  before(() => {
    process.env.AUTH_SECRET = 'test-secret-key';
    server = createServer(port);
  });

  after(() => {
    server.close();
  });

  /**
   * 로그인 API에 POST 요청을 보낸다.
   * @param {Record<string, string>} body - 요청 본문
   * @returns {Promise<{ statusCode: number, body: unknown }>}
   */
  function postLogin(body) {
    return new Promise((resolve, reject) => {
      const payload = JSON.stringify(body);
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port,
          path: '/api/login',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload),
          },
        },
        (res) => {
          const chunks = [];
          res.on('data', (chunk) => chunks.push(chunk));
          res.on('end', () => {
            resolve({
              statusCode: res.statusCode ?? 0,
              body: JSON.parse(Buffer.concat(chunks).toString('utf8')),
            });
          });
        },
      );
      req.on('error', reject);
      req.write(payload);
      req.end();
    });
  }

  it('성공 시 200과 토큰을 반환한다', async () => {
    const { statusCode, body } = await postLogin({
      email: 'admin@example.com',
      password: 'admin123',
    });
    assert.equal(statusCode, 200);
    assert.equal(typeof body.token, 'string');
    assert.equal(body.expiresIn, 3600);
  });

  it('실패 시 401과 일반 오류 메시지를 반환한다', async () => {
    const { statusCode, body } = await postLogin({
      email: 'admin@example.com',
      password: 'wrong',
    });
    assert.equal(statusCode, 401);
    assert.equal(body.error, '이메일 또는 비밀번호가 올바르지 않습니다.');
  });
});
