import crypto from 'node:crypto';
import { isValidEmail, normalizeEmail } from './validator.js';

const TOKEN_TTL_SECONDS = 3600;

/**
 * 데모용 사용자 저장소. 실제 서비스에서는 DB를 사용한다.
 * @type {Map<string, { passwordHash: string, salt: string }>}
 */
const users = new Map([
  [
    normalizeEmail('admin@example.com'),
    {
      salt: 'demo-salt-admin',
      passwordHash: hashPassword('admin123', 'demo-salt-admin'),
    },
  ],
]);

/**
 * 비밀번호를 scrypt로 해시한다.
 * @param {string} password - 평문 비밀번호
 * @param {string} salt - 솔트
 * @returns {string} 해시 문자열
 */
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

/**
 * 타이밍 공격을 줄이기 위해 두 버퍼를 상수 시간으로 비교한다.
 * @param {string} a - 비교할 문자열
 * @param {string} b - 비교할 문자열
 * @returns {boolean} 일치 여부
 */
function safeEqual(a, b) {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) {
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

/**
 * 로그인 토큰을 발급한다.
 * @param {string} email - 사용자 이메일
 * @returns {string} 서명된 토큰
 */
function issueToken(email) {
  const secret = process.env.AUTH_SECRET;
  if (!secret) {
    throw new Error('AUTH_SECRET 환경 변수가 설정되지 않았습니다.');
  }

  const payload = {
    sub: email,
    exp: Math.floor(Date.now() / 1000) + TOKEN_TTL_SECONDS,
  };
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto
    .createHmac('sha256', secret)
    .update(body)
    .digest('base64url');

  return `${body}.${signature}`;
}

/**
 * 이메일과 비밀번호로 사용자를 인증한다.
 * @param {string} email - 로그인 이메일
 * @param {string} password - 로그인 비밀번호
 * @returns {{ token: string, expiresIn: number } | null} 성공 시 토큰 정보, 실패 시 null
 */
export function login(email, password) {
  if (typeof email !== 'string' || typeof password !== 'string') {
    return null;
  }

  if (!isValidEmail(email) || password.length === 0) {
    return null;
  }

  const normalizedEmail = normalizeEmail(email);
  const user = users.get(normalizedEmail);
  if (!user) {
    return null;
  }

  const candidateHash = hashPassword(password, user.salt);
  if (!safeEqual(candidateHash, user.passwordHash)) {
    return null;
  }

  return {
    token: issueToken(normalizedEmail),
    expiresIn: TOKEN_TTL_SECONDS,
  };
}
