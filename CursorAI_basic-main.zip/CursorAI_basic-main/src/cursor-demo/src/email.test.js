import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { extractEmails, isValidEmail, getValidEmails } from './email.js';

describe('extractEmails', () => {
  it('배열에서 이메일만 추출한다', () => {
    const users = [
      { name: 'Alice', email: 'alice@example.com' },
      { name: 'Bob', email: 'bob@test.org' },
    ];
    assert.deepEqual(extractEmails(users), ['alice@example.com', 'bob@test.org']);
  });

  it('배열이 아니면 빈 배열을 반환한다', () => {
    assert.deepEqual(extractEmails(null), []);
    assert.deepEqual(extractEmails('not-array'), []);
  });
});

describe('isValidEmail', () => {
  it('유효한 이메일 형식을 통과시킨다', () => {
    assert.equal(isValidEmail('user@example.com'), true);
    assert.equal(isValidEmail('a.b@c.co'), true);
    assert.equal(isValidEmail('user+newsletter@gmail.com'), true);
    assert.equal(isValidEmail('first_last@example.org'), true);
  });

  it('유효하지 않은 이메일 형식을 거부한다', () => {
    assert.equal(isValidEmail('invalid'), false);
    assert.equal(isValidEmail('missing@domain'), false);
    assert.equal(isValidEmail('user @domain.com'), false);
    assert.equal(isValidEmail("o'brien@company.ie"), false);
    assert.equal(isValidEmail(null), false);
    assert.equal(isValidEmail(123), false);
  });
});

describe('getValidEmails', () => {
  it('유효한 이메일만 추출한다', () => {
    const users = [
      { email: 'good@example.com' },
      { email: 'bad-email' },
      { email: 'also@valid.org' },
      { email: null },
    ];
    assert.deepEqual(getValidEmails(users), ['good@example.com', 'also@valid.org']);
  });

  it('배열이 아니면 빈 배열을 반환한다', () => {
    assert.deepEqual(getValidEmails(undefined), []);
  });
});
